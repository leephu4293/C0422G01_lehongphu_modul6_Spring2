package com.sprint2.book_store_webservice.repository;

public interface IAppUserRepository {
}
