package com.sprint2.book_store_webservice.model;

public  class B extends A {
    private String c = "sdsafsa";
    public  void dodo(){
        System.out.println("ádadad");
    }

    public B() {
    }

    public B(String test, String test1, String c) {
        super(test, test1);
        this.c = c;
    }

    public static void main(String[] args) {
        B b = new B();
        A c = new B("2","3","C");
        A d = new A();
        c.test1 ="qeqeqe";
        System.out.println(c.test1);
        System.out.println(b.test1);
    }
}

