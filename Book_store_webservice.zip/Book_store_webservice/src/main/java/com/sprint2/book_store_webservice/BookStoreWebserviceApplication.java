package com.sprint2.book_store_webservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookStoreWebserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookStoreWebserviceApplication.class, args);
    }

}
