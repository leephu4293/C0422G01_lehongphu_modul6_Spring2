package com.sprint2.book_store_webservice.model;




public  class A {
    private  String test ="hihihi";
    protected   String test1="hehehe";
     public String doSomeThing(String a){
         return "hi";
     };

    public A() {
    }

    public A(String test, String test1) {
        this.test = test;
        this.test1 = test1;
    }
}
