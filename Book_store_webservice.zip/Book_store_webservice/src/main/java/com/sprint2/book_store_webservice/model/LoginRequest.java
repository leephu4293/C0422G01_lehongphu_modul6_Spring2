package com.sprint2.book_store_webservice.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginRequest {
    String username;

    String password;
}
