package com.sprint2.book_store_webservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreWebserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
